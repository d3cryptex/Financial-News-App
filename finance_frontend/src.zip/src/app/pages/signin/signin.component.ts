
declare var google: any;
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { UserService } from '../../data/services/user.service';
import { AuthService } from '../../data/services/auth.service';
import { User } from '../../data/interfaces/user';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-signin',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './signin.component.html',
  styleUrl: './signin.component.css'
})

export class SigninComponent {
  signInForm!: FormGroup;

  users: User[] = [];
  emailTaken = false;
  emailLinkedToGoogle = false;

  constructor(private formBuilder: FormBuilder, private authService: AuthService, private userService: UserService, private router: Router, private http: HttpClient) { }

  navigate_SignUp() {
    this.router.navigate(['signup']);
  }

  ngOnInit() {
    const savedUser = this.authService.getUserData();
    if (savedUser) 
      this.router.navigate(['/profile', savedUser.id]);

    this.signInForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required]],
      stay: [false]
    });

    this.userService.getUsers().subscribe((users: User[]) => {
      this.users = users;
    });

    google.accounts.id.initialize({
      client_id: '19662891390-6g6ttj9ge35jb0gqtiou5vedra9hgao4.apps.googleusercontent.com',
      callback: (response: any) => this.onGoogleLogin(response)
    });

    google.accounts.id.renderButton(document.getElementById("google-btn"), {
      theme: 'filled_blue',
      size: 'large',
      shape: 'rectangle',
      width: 300
    })
  }

  decodeToken(token: string) {
    const base64Url = token.split(".")[1];
    const base64 = base64Url.replace(/-/g, "+").replace(/_/g, "/"); 
    const padding = '='.repeat((4 - base64.length % 4) % 4); 
  
    const json = atob(base64 + padding);
    return JSON.parse(decodeURIComponent(escape(json)));
  }

  onGoogleLogin(response: any) {
    if (response) {      
      const tokenLoad = this.decodeToken(response.credential);
      console.log("Декодированные данные от Google:", tokenLoad);

      const userData = {
        name: tokenLoad.name,
        email: tokenLoad.email,
        googleid: tokenLoad.sub, 
      };

      console.log("Декодированные данные от Google:", userData.name);

      this.checkEmailLinkedToGoogle(userData);
    }
  }

  checkEmail(): void {
    const email = this.signInForm.get('email')?.value;
    if (email) {
      this.userService.checkEmailExists(email).subscribe((exists) => {
        this.emailTaken = exists;
      });
    }
  }

  checkIsGoogleAccaunt(): void {
    const email = this.signInForm.get('email')?.value;
    if (email) {
      this.userService.checkEmailLinkedToGoogle(email).subscribe((exists) => {
        this.emailLinkedToGoogle = exists;
      });
    }
  }

  checkEmailLinkedToGoogle(userdata: any): void {
    this.userService.checkEmailLinkedToGoogle(userdata.email).subscribe((exists) => {
      this.emailLinkedToGoogle = exists;

      if (this.emailLinkedToGoogle) {
        this.authorizeUser(userdata);
      } 
    });
  }

  authorizeUser(userdata: any): void {
    this.userService.createGoogleUser(userdata).subscribe(
      (user) => {
        this.authService.saveUserData(user);
        console.log('Пользователь успешно создан или обновлен:', user);
        this.router.navigate(['']);
      },
      (error) => {
        console.error('Ошибка при отправке данных на сервер:', error);
      }
    );
  }

  onSubmit() {
    const email = this.formControls['email'].value;
    const password = this.formControls['password'].value;
    const stay = this.formControls['stay'].value;

    if (this.emailLinkedToGoogle) 
      return; 

    this.userService.validateUser(email, password).subscribe(
      (user) => {
        if (user) {
          if (stay) {
            this.authService.saveUserData(user);
          }

          this.router.navigate(['/profile', user.id]);
        }
      },
      (error) => {
        console.error(error);
        console.log('Неверный email или пароль');
      }
    );
  }

  get formControls() {
    return this.signInForm.controls;
  }
}
