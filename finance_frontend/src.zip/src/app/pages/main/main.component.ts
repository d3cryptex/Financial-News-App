import { Component, OnInit, CUSTOM_ELEMENTS_SCHEMA, ViewChild, ElementRef, ViewEncapsulation, AfterViewInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { NewsCardsComponent } from '../../elements/news-cards/news-cards.component';
import { HeaderComponent } from "../../elements/header/header.component";
import { SwiperContainer } from 'swiper/element';
import { CurrencyService, CryptoData } from '../../data/services/currency.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-main',
  standalone: true,
  imports: [CommonModule, NewsCardsComponent, HeaderComponent],
  templateUrl: './main.component.html',
  styleUrl: './main.component.css',
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})

export class MainComponent implements AfterViewInit, OnInit  {
  @ViewChild('swiperContainer') swiperContainer?: ElementRef<SwiperContainer>;

  constructor(private currencyService: CurrencyService) { } 

  cryptoData$?: Observable<CryptoData[]>;
  loadingError: string | null = null; 

  ngOnInit(): void {
    this.cryptoData$ = this.currencyService.getMarketData();

    this.cryptoData$.subscribe({
      error: (err) => {
        console.error('Error caught in component:', err);
        this.loadingError = err.message || 'Failed to load cryptocurrency data.';
      }
    });
  }

  getChangeClass(change: number | undefined | null): string {
    if (change == null) return '';
    if (change > 0) return 'positive';
    if (change < 0) return 'negative';
    return '';
  }

  slides = [1, 2, 3, 4, 5, 6];

  swiperBreakpoints = {
    '640': { slidesPerView: 2, spaceBetween: 15 },
    '1024': { slidesPerView: 3, spaceBetween: 20 },
    '1200': { slidesPerView: 4, spaceBetween: 20 } 
  };

  ngAfterViewInit(): void {
    if (this.swiperContainer) {
      console.log('Initializing Swiper manually...'); 
      this.swiperContainer.nativeElement.initialize();
    } else {
      console.error('Swiper container not found!'); 
    }
  }
}
