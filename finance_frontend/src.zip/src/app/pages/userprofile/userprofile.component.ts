declare var google: any;
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { User } from '../../data/interfaces/user';
import { UserService } from '../../data/services/user.service';
import { AuthService } from '../../data/services/auth.service';

@Component({
  selector: 'app-userprofile',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './userprofile.component.html',
  styleUrl: './userprofile.component.css'
})

export class UserprofileComponent {
  user: User | null = null;  
  userId: string | null = null;
  loggedInUserId: string | null = null;

  constructor(private userService: UserService, private authService: AuthService, private route: ActivatedRoute, private router: Router) {}

  ngOnInit(): void {
    const savedUser = this.authService.getUserData();
    this.user = savedUser

    if (!savedUser) {
      this.router.navigate(['']);
      return;
    }

    this.loggedInUserId = savedUser.id

    this.route.paramMap.subscribe((params) => {
      this.userId = params.get('id');

      if (!this.userId) {
        this.router.navigate(['/profile', this.loggedInUserId]); 
        return;
      }

      if (this.userId !== this.loggedInUserId) {
        this.router.navigate(['/profile', this.loggedInUserId]); 
        return;
      }

      if (this.userId) {
        this.getUserData();
      }
    });
  }

  getUserData(): void {
    if (this.userId) {
      this.userService.getUserById(this.userId).subscribe(
        (data) => {
          this.user = data;  
        },
        (error) => {
          console.error('Ошибка при получении данных пользователя', error);
        }
      );
    }
  }

  signOut(): void {
    this.authService.logout();
    
    if(this.user?.isGoogleAccount) 
      google.accounts.id.disableAutoSelect();

    this.router.navigate(['']);
  }
}
