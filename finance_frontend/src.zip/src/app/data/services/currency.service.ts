import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http'; 
import { Observable, catchError, tap, throwError } from 'rxjs';

export interface CryptoData {
  id: string;
  symbol: string;
  name: string;
  image: string;
  current_price: number;
  market_cap: number;
  market_cap_rank: number;
  total_volume: number;
  price_change_percentage_24h: number; 
}

@Injectable({
  providedIn: 'root'
})

export class CurrencyService {

  private apiUrl = 'https://api.coingecko.com/api/v3'; 

  constructor(private http: HttpClient) { }

  /**
   * 
   * @param vs_currency 
   * @param per_page 
   * @param page 
   * @param order 
   */
  getMarketData(
    vs_currency: string = 'usd',
    per_page: number = 50, 
    page: number = 1,
    order: string = 'market_cap_desc'
  ): Observable<CryptoData[]> {

    let params = new HttpParams()
      .set('vs_currency', vs_currency)
      .set('order', order)
      .set('per_page', per_page.toString())
      .set('page', page.toString())
      .set('sparkline', 'false') 
      .set('price_change_percentage', '24h');

    const url = `${this.apiUrl}/coins/markets`;

    console.log(`Workspaceing crypto data from: ${url} with params:`, params.toString()); 

    return this.http.get<CryptoData[]>(url, { params: params }).pipe(
      tap(data => console.log('Received crypto data:', data)), 
      catchError(error => {
        console.error('Error fetching crypto data:', error); 
        return throwError(() => new Error('Failed to fetch crypto data from CoinGecko API.'));
      })
    );
  }
}
