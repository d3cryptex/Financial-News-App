import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { News } from '../interfaces/news';

@Injectable({
  providedIn: 'root'
})

export class NewsService {

  

  constructor() { }
}
