export interface News {
    id: string;
    title: string;
    vendor: string;
    date: Date;
    description: string[];
    image: string;
}
