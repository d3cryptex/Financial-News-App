import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { User } from '../../data/interfaces/user';
import { AuthService } from '../../data/services/auth.service';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './header.component.html',
  styleUrl: './header.component.css'
})
export class HeaderComponent implements OnInit {
  user: User | null = null;
  showMenu: boolean = false;
  
  constructor(private router: Router, private authService: AuthService) {}

  ngOnInit() {
    this.user = this.authService.getUserData();
  }

  navigate_SignIn() {
    this.router.navigate(['signin']);
  }

  navigate_Profile() {
    if (this.user && this.user.id) {
      this.router.navigate(['/profile', this.user.id]);
    } else {
      console.error('Ошибка: user.id отсутствует!', this.user);
    }
  }

  toggleMenu() {
    this.showMenu = !this.showMenu;
  }
}
