import { Component, Input, ElementRef} from '@angular/core';
import { CommonModule } from '@angular/common';
import { News } from '../../data/interfaces/news';

@Component({
  selector: 'app-news-cards',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './news-cards.component.html',
  styleUrl: './news-cards.component.css'
})

export class NewsCardsComponent {
  private news: News[] = [
    {
        id: "1",
        title: "Stock Markets Plummet After Fed Announcement",
        vendor: "Bloomberg",
        date: new Date("2025-03-20"),
        description: [
            "The Federal Reserve has announced a potential interest rate hike.",
        ],
        image: "assets/img/usa.jpg"
    },
    {
        id: "2",
        title: "Bitcoin Reaches New All-Time High",
        vendor: "CoinDesk",
        date: new Date("2025-03-02"),
        description: [
            "Bitcoin has surpassed $100,000 for the first time in history.",
        ],
        image: "assets/img/bitcoin.jpg"
    },
    {
        id: "3",
        title: "Apple Unveils New iPhone with Revolutionary Features",
        vendor: "TechCrunch",
        date: new Date("2025-03-21"),
        description: [
            "The latest iPhone boasts an improved camera and AI integration.",
        ],
        image: "assets/img/apple.jpg"
    },
    {
        id: "4",
        title: "Elon Musk Announces SpaceX Orbital Hotel",
        vendor: "NASA",
        date: new Date("2025-03-11"),
        description: [
            "SpaceX plans to open the first commercial space hotel by 2030.",
        ],
        image: "assets/img/hotel.jpg"
    },
    {
        id: "5",
        title: "Tesla Unveils New Roadster with 1000km Range",
        vendor: "Reuters",
        date: new Date("2025-03-01"),
        description: [
            "The Tesla Roadster 2.0 can drive 1000 km on a single charge.",
        ],
        image: "assets/img/tesla.jpg"
    },
    {
        id: "6",
        title: "Microsoft Announces New AI-Powered Office Suite",
        vendor: "TechRadar",
        date: new Date("2025-03-15"),
        description: [
            "Microsoft's new office suite integrates AI for better productivity.",
        ],
        image: "assets/img/microsoft.jpg"
    },
    {
        id: "7",
        title: "Google Launches Quantum Computer Research Facility",
        vendor: "Wired",
        date: new Date("2025-03-18"),
        description: [
            "Google has opened a new facility dedicated to quantum computing research.",
        ],
        image: "assets/img/google.jpg"
    },
    {
        id: "8",
        title: "Amazon Acquires New Space for Future Headquarters",
        vendor: "Business Insider",
        date: new Date("2025-03-17"),
        description: [
            "Amazon has purchased land for the construction of a new global headquarters.",
        ],
        image: "assets/img/amazon.jpg"
    },
    {
        id: "9",
        title: "NASA's Mars Rover Discovers New Evidence of Water",
        vendor: "NASA",
        date: new Date("2025-03-10"),
        description: [
            "NASA's Mars rover has found evidence of ancient water on the planet.",
        ],
        image: "assets/img/mars.jpg"
    },
    {
        id: "10",
        title: "New AI Tool Can Predict Natural Disasters",
        vendor: "MIT Technology Review",
        date: new Date("2025-03-05"),
        description: [
            "A new AI tool can predict natural disasters with high accuracy.",
        ],
        image: "assets/img/ai_tool.jpg"
    }
  ];


  private sortedNews = this.news.sort((a, b) => b.date.getTime() - a.date.getTime());

  mainNews = this.sortedNews[0]; 
  latestNews = this.sortedNews.slice(1, 6);

  otherNews = this.sortedNews.slice(1);
}
